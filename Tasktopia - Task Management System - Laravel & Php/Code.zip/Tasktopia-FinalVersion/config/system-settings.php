<?php

return [
    'name' => 'Task Management System',
    'email' => 'info@sample.comm',
    'contact' => '+6948 8542 623',
    'address' => '2102 Caldwell Road, Rochester, New York, 14608',
    'cover_img' => '',
];
?>